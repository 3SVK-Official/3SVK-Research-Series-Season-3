# Proposed System Architecture

**Status:** Design proposal. Verify against the actual repository before describing any component as implemented.

## Data flow

```text
Authorized source records / approved document samples
                      |
                      v
             Intake and validation
                      |
                      v
          Parsing and normalization
                      |
                      v
       Entity and field extraction
                      |
                      v
          Candidate entity resolution
                      |
                      v
        Evidence + provenance records
                      |
                      v
           Temporal knowledge graph
                      |
          +-----------+-----------+
          |                       |
          v                       v
 Graph / timeline analysis   Document review signals
          |                       |
          +-----------+-----------+
                      |
                      v
       Explainable investigator workspace
                      |
                      v
        Human review, correction, audit
```

## Design rules

1. Every fact and relationship should retain a source reference.
2. Store source facts separately from derived inferences.
3. Use explicit timestamps or intervals where available; do not invent missing time values.
4. Keep ambiguous entity matches separate until reviewed.
5. Expose the reason for a suggested relationship and its uncertainty.
6. Treat document flags as review signals, not definitive fraud findings.
7. Do not connect to restricted systems without authorization and security approval.
8. Apply least privilege, auditability, retention rules, and secure handling of uploads.

## Conceptual components

- Intake adapter: validates files, metadata, authorization, and supported formats.
- Normalization/extraction: converts approved inputs to structured candidate records.
- Entity resolution: proposes possible duplicate records and preserves uncertainty.
- Evidence store: keeps provenance and transformation history.
- Graph service: stores or queries entities, events, and relationships.
- Analytics service: computes descriptive graph and temporal results.
- Document screening: extracts fields and runs only validated checks.
- Review interface: shows evidence and supports investigator correction.
- Security/audit layer: enforces permissions and records sensitive actions.

## Implementation status checklist

Mark each item only after checking the actual code and running an appropriate test.

- [ ] Intake and file validation implemented
- [ ] Entity schema and persistence implemented
- [ ] Provenance attached to graph relationships
- [ ] Entity resolution implemented and evaluated
- [ ] Temporal filtering implemented
- [ ] Graph measures implemented and tested
- [ ] Document extraction implemented and tested
- [ ] Document anomaly checks evaluated on suitable data
- [ ] Human review and correction workflow implemented
- [ ] Role-based access controls tested
- [ ] Audit trail tested
- [ ] Retention/deletion behavior documented
- [ ] Security review completed
