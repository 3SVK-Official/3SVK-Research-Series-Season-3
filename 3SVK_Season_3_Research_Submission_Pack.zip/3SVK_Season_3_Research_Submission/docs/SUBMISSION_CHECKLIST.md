# 3SVK Submission Checklist

## Before uploading
- [ ] Confirm the final project title.
- [ ] Add the actual author/applicant name(s); obtain consent from any co-applicant or mentor.
- [ ] Add institution and framework/challenge identifier accurately.
- [ ] Verify which features exist in code and which are proposed.
- [ ] Remove unresolved placeholders or clearly mark them where the organizer permits.
- [ ] Add only references that have been checked and read.
- [ ] Add measured results only if the experiments were actually performed.
- [ ] Check Markdown formatting and all links.
- [ ] Ensure no passwords, API keys, private keys, personal identity data, or restricted records are present.
- [ ] Confirm the 3SVK repository's current file naming and placement requirements.

## Files in this pack
- `PROCEEDINGS.md` — main research proceedings draft.
- `docs/ARCHITECTURE.md` — proposed architecture and implementation checklist.
- `docs/METHODOLOGY_AND_EVALUATION.md` — research questions, methods, metrics, and results template.
- `docs/SECURITY_PRIVACY_AND_ETHICS.md` — proposed safeguards and review checklist.
- `docs/SUBMISSION_CHECKLIST.md` — pre-submission checks.

## GitHub workflow from the participant guide
1. Fork the official 3SVK Season 3 repository.
2. Add or upload the required Markdown proceedings file and supporting documents.
3. Commit the changes to your fork.
4. Open a Pull Request against the official repository and submit it.
5. Take a screenshot showing the submitted Pull Request and your GitHub ID.
6. Upload the screenshot to Unstop with your GitHub profile link.

Official repository: https://github.com/3SVK-Official/3SVK-Research-Series-Season-3

Do not claim the submission is complete until the Pull Request exists and the proof has been uploaded as required.
