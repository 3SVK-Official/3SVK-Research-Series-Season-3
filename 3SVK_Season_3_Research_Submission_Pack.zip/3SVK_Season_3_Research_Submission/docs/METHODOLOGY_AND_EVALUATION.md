# Methodology and Evaluation Plan

## Research questions

1. Can evidence-linked graph representations make cross-record relationships easier to inspect than a record-by-record workflow?
2. How accurately can the selected entity-resolution method identify duplicate records while controlling false merges?
3. Do explanations and source provenance help reviewers assess suggested links?
4. How does the selected document-screening method perform on a representative, properly authorized evaluation set?
5. What latency, usability, privacy, and security limitations arise under the intended workload?

These are questions to test, not conclusions already established.

## Proposed experimental design

### Dataset
Begin with synthetic records for functional tests. For performance evaluation, use a documented, lawfully authorized and appropriately de-identified dataset. Record dataset origin, schema, labeling process, exclusions, and limitations. Never upload real identity documents or sensitive investigative data to a public repository.

### Baselines
Select a clear baseline for each task, such as manual record lookup, deterministic exact-match resolution, or a simple rule-based document validation method. Describe baseline settings and ensure the comparison uses the same test cases.

### Metrics
- Extraction: precision, recall, F1 by entity/field type.
- Entity resolution: pairwise precision/recall, false-merge rate, missed-match rate.
- Link suggestions: precision@k, reviewer usefulness ratings, and explanation completeness.
- Document screening: sensitivity, specificity, false-positive rate, and performance by document type/quality.
- System: latency distribution, throughput, error rate, resource use, and recovery behavior.
- Governance: provenance coverage, access-control test outcomes, audit completeness, and deletion verification.

### Procedure
1. Define test cases and acceptance criteria before testing.
2. Separate development data from evaluation data where model fitting is involved.
3. Record software versions, parameters, environment, and test seed where applicable.
4. Run tests repeatedly when measurements are variable.
5. Report negative results, failure cases, uncertainty, and known limitations.
6. Avoid generalizing from synthetic data to real-world effectiveness.

## Results table template

| Test | Dataset / sample size | Metric | Result | Environment | Notes |
|---|---|---|---|---|---|
| Entity extraction | [Fill in] | [Precision/recall/F1] | Not measured | [Fill in] | Do not invent values |
| Entity resolution | [Fill in] | [False-merge rate] | Not measured | [Fill in] | Do not invent values |
| Link analysis | [Fill in] | [Precision@k] | Not measured | [Fill in] | Do not invent values |
| Document screening | [Fill in] | [Sensitivity/specificity] | Not measured | [Fill in] | Do not invent values |
| System performance | [Fill in] | [Latency/throughput] | Not measured | [Fill in] | Do not invent values |

## Reporting rule
Only replace “Not measured” with a result after conducting the test and retaining enough evidence to reproduce it.
